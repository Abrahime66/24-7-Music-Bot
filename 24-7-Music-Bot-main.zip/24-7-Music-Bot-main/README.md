# 24-7-Music-Bot

## 24/7 Music Bot <img src="https://cdn.discordapp.com/attachments/793805187353542667/794171863885938688/circle-cropped.png" width="25px" heigh="25px"> 

## Setup the Bot
### Go to `config.json` and Fill it and then
### type `npm i` after Everything Installs
### type `npm start`
### and the Bot will Start working
